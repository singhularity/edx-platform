#!/usr/bin/env python

from setuptools import setup, find_packages

setup(
    name='wgen.metrics',
    description='Generic metrics logging',
    author='SPT',
    author_email='spt@wgen.net',
    packages=find_packages(exclude=['tests']),
    namespace_packages=['wgen'],
    version='2.0.0',
    zip_safe=False,
    install_requires=[],
    test_suite='nose.collector',
    tests_require=[
        'nose',
        'coverage',
        'mock',
    ],
    setup_requires=['nose'],
)
