"""
Specifies where and how to record the metrics and events.  This expects the
user to specify a global ``metrics`` logger and handler.
"""
import logging

SEPARATOR = " | "

__all__ = ['counter', 'event', 'gauge']

# Applications should specify a `metrics` handler for this information.
log = logging.getLogger('metrics')


def write_metric(*fields):
    """
    Writes a specific ``type`` to the log, appending ``fields`` separated by
    pipes.
    """
    assert len(fields) >= 2, "write_metric requires at least two fields."
    log.info(SEPARATOR.join([unicode(field) for field in fields]))


def counter(counter_name, amount, units=""):
    """
    Will write a `COUNTER` statement out to the specified `metrics.log`.

    ``counter_name``
        Name of the metric counter to increment.
    ``amount``
        Numerical number to increment this value by.
    ``units``
        If specified, should indicate the units for the ``amount``.
    """
    write_metric("COUNTER", counter_name, amount, units)


def event(event_name):
    """
    Writes an `EVENT` statement to the log.  An event can be anything that
    should be marked on the event statistics gatherer, but should be limited to
    statistically relevant events only.

    ``event_name``:
        Name of the event to be triggered.
    """
    write_metric("EVENT", event_name)


def gauge(gauge_name, amount, units=""):
    """
    Will write a `GAUGE` statement out to the specified `metrics.log`.

    ``gauge_name``
        Name of the gauge metric.
    ``amount``
        Numerical number to specify.
    ``units``
        If specified, should indicate the units for the ``amount``.
    """
    write_metric("GAUGE", gauge_name, amount, units)


def timer(timer_name, duration, units=""):
    """
    Track a the duration of some event,

    ``timer_name``
        Name of the timer metric.
    ``duration``
        The duration of the event.
    ``unit``
        Optionally, specify the units of the ``duration``.
    """
    # HACK mperpick: the DataDog API expects counters and gauges. Counters are
    # summed and gauges are averaged, so as a hack until their API is improved
    # let's just call a timer a gauge.
    gauge(timer_name, duration, units)

