try:
    from setuptools import setup, find_packages
except ImportError:
    from ez_setup import use_setuptools
    use_setuptools()
    from setuptools import setup, find_packages

setup(
    name='wgen.logger',
    version='2.3.1',
    install_requires=[
        "wgen.metrics>=2.0.0",
        "method_decorator==0.1.3",  # https://github.com/denis-ryzhkov/method_decorator
        "decorator==3.4.0,<4",
        "mock>=1.0.1,<2"
    ],
    namespace_packages=['wgen'],
    packages=find_packages(),
    zip_safe=False,
)
