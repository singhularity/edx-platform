"""
A set of functions for recording timing data of key operations in the style of DDP12
(http://wiki.wgenhq.net/wiki/index.php/DPP/12#Stat_Logs)
"""
from __future__ import with_statement
from __future__ import absolute_import

import logging
import time
from contextlib import contextmanager
from decorator import decorator
from wgen.logger.core import format_log_fields
from wgen.metrics import counter, timer
from wgen.logger.escape import escape

statLogger = logging.getLogger('stat')

def _format_stat_line(metric_name, elapsed_secs, success, data_in=None, data_in_units=None, data_out=None, data_out_units=None, tracekey=None, extra=None):
    """
    Returns the log line (string) formatting its arguments to the stats logging standard (http://wiki.wgenhq.net/wiki/index.php/DPP/12#Stat_Logs)
    
    ``metric_name`` (string):
        The dot-separated name specifying the metric being measured. Cannot
        contain the '|' character
    ``elapsed_secs`` (number):
        How long the operation took, in seconds.
    ``success`` (bool):
        Whether the operation was successful
    ``data_in`` (number):
        A numeric value measuring the amount of input data for the operation
    ``data_in_units`` (string):
        The units for ``data_in``. Should be consistent across all uses of
        ``metric_name``
    ``data_out`` (number):
        A numeric value measuring the amount of data produced by this operation
    ``data_out_units`` (string):
        The units for ``data_out``. Should be consistent across all uses of
        ``metric_name``
    ``tracekey``:
        A unique key used to track a request through the entire system
    ``extra``:
        Any extra data to be attached to the log entry. Will be converted to a string
        using ``str`` before being written to the log

    Raises wgen.logger.core.InvalidFieldError is any field contains the field separator
    """
    return format_log_fields(
        [
            metric_name,
            elapsed_secs,
            data_in,
            data_in_units,
            data_out,
            data_out_units,
            'SUCCESS' if success else 'FAILURE',
            tracekey,
            extra,
        ]
    )
    

def stats(metric_name, elapsed_secs, success, data_in=None, data_in_units=None, data_out=None, data_out_units=None, extra=None, tracekey=None):
    """
    Record a stat line to the "stats" logger according to the logging standard (http://wiki.wgenhq.net/wiki/index.php/DPP/12#Stat_Logs)
    
    ``metric_name`` (string):
        The dot-separated name specifying the metric being measured. Cannot
        contain the '|' character
    ``elapsed_secs`` (number):
        How long the operation took, in seconds.
    ``success`` (bool):
        Whether the operation was successful
    ``data_in`` (number):
        A numeric value measuring the amount of input data for the operation
    ``data_in_units`` (string):
        The units for ``data_in``. Should be consistent across all uses of
        ``metric_name``
    ``data_out`` (number):
        A numeric value measuring the amount of data produced by this operation
    ``data_out_units`` (string):
        The units for ``data_out``. Should be consistent across all uses of
        ``metric_name``
    ``extra``:
        Any extra data to be attached to the log entry. Will be converted to a string
        using ``str`` before being written to the log
    ``tracekey``:
        A unique key used to track a request through the entire system

    Raises wgen.logger.core.InvalidFieldError is any field contains the field separator
    """
    log_line = _format_stat_line(
        metric_name=metric_name,
        elapsed_secs=elapsed_secs,
        success=success,
        data_in=data_in,
        data_in_units=data_in_units,
        data_out=data_out,
        data_out_units=data_out_units,
        tracekey=tracekey,
        extra=extra,
    )
    statLogger.info(log_line)

    # Also counter the metrics for stat
    escaped_metric_name = escape(metric_name)
    escaped_data_in_units = data_in_units if data_in_units is None else escape(data_in_units) 
    escaped_data_out_units = data_out_units if data_out_units is None else escape(data_out_units)

    if success:
        counter("%s.success" % escaped_metric_name, 1)
    else:
        counter("%s.failure" % escaped_metric_name, 1)

    timer("%s.elapsed_time" % escaped_metric_name, elapsed_secs, 'seconds')

    if data_in:
        data_in_metric_name = "%s.data_in" % escaped_metric_name
        counter(data_in_metric_name, data_in, escaped_data_in_units or '')

    if data_out:
        data_out_metric_name = "%s.data_out" % escaped_metric_name
        counter(data_out_metric_name, data_out, escaped_data_out_units or '')


# Structure to be passed to "timed" context, to be given data for logging
class TimerReport(object):
    """
    Object used for adding additional data during the execution of the
    ``timed`` contextmanager.

    ``success`` (bool):
        Whether the operation was successful
    ``data_in`` (number):
        A numeric value measuring the amount of input data for the operation
    ``data_out`` (number):
        A numeric value measuring the amount of data produced by this operation
    ``extra``:
        Any extra data to be attached to the log entry. Will be converted to a string
        using ``str`` before being written to the log
    ``tracekey``:
        A unique key used to track a request through the entire system
    """
    # __slots__ offers typo protection.
    __slots__ = 'data_in', 'data_out', 'success', 'tracekey', 'extra'
    
    def __init__(self, data_in=None, data_out=None, success=True, extra=None, tracekey=None):
        self.data_in = data_in
        self.data_out = data_out
        self.success = success
        self.extra = extra
        self.tracekey = tracekey

@contextmanager
def timed(metric_name, data_in_units=None, data_out_units=None, extra=None, tracekey=None):
    """
    A context manager that will time the surrounded code. Returns a ``TimerReport``
    object so that ``data_in``, ``data_out``, and ``success`` can be set inside
    the timing call if they aren't known beforehand. ``success`` is assumed to be
    true unless it is set via the ``TimerReport`` or an exception is thrown

    ``metric_name`` (string):
        The dot-separated name specifying the metric being measured. Cannot
        contain the '|' character
    ``data_in_units`` (string):
        The units for ``data_in``. Should be consistent across all uses of
        ``metric_name``
    ``data_out_units`` (string):
        The units for ``data_out``. Should be consistent across all uses of
        ``metric_name``
    ``extra``:
        Any extra data to be attached to the log entry. Will be converted to a string
        using ``str`` before being written to the log
    ``tracekey``:
        A unique key used to track a request through the entire system

    Raises wgen.logger.core.InvalidFieldError is any field contains the field separator
    """
    start = time.time()
    report = TimerReport(extra=extra, success=None, tracekey=tracekey)
    try:
        yield report
        if report.success is None:
            report.success = True
    except:
        if report.success is None:
            report.success = False
        raise
    finally:
        elapsed_secs = time.time() - start
        stats(
            metric_name=metric_name,
            elapsed_secs=elapsed_secs,
            data_in=report.data_in,
            data_in_units=data_in_units,
            data_out=report.data_out,
            data_out_units=data_out_units,
            success=report.success,
            tracekey=report.tracekey,
            extra=report.extra,
        )

def timed_fn(metric_name, data_in_units=None, data_out_units=None, tracekey=None):
    """
    A decorator that records an entry in the stat log that times the wrapped function.

    ``metric_name`` (string):
        The dot-separated name specifying the metric being measured

    Raises wgen.logger.core.InvalidFieldError if any field contains the field separator
    """
    @decorator
    def wrapper(fn, *args, **kwargs):
        with timed(
            metric_name=metric_name,
            data_in_units=data_in_units,
            data_out_units=data_out_units,
            extra=dict(args=args, kwargs=kwargs),
            tracekey=tracekey):
            
            return fn(*args, **kwargs)
    return wrapper
