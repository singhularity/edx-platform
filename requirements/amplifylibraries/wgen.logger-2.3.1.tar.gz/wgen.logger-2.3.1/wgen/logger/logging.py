"""
A set of functions for logging application failures and debugging information
in the style of DDP12 (http://wiki.wgenhq.net/wiki/index.php/DPP/12#Error_Logs)
"""

# Use absolute imports so that we can import logging rather than wgen.logger.logging
from __future__ import absolute_import

import logging
from logging import CRITICAL, ERROR, WARNING, INFO, DEBUG

from wgen.logger.core import format_log_fields

errorLogger = logging.getLogger('application')

LOG_LINE_LIMIT = 65536

def _format_error_line(message, tracekey=None, log_type=None):
    """
    Returns the log line (string) formatting its arguments to the error logging
    standard (http://wiki.wgenhq.net/wiki/index.php/DPP/12#Error_Logs)

    ``message`` (string):
        The message to log
    ``log_type`` (string):
        A dot-separated string identifying the type of the log message
    ``tracekey``:
        A unique key used to track a request through the entire system

    Raises wgen.logger.core.InvalidFieldError is any field contains the field separator
    """
    return format_log_fields(
        [
            log_type,
            tracekey,
            message,
        ]
    )

def log(severity, msg, log_type, tracekey=None, **kwargs):
    """
    Log a single message in the format specified by DDP12
    (http://wiki.wgenhq.net/wiki/index.php/DPP/12#Error_Logs)

    ``severity``:
        One of ``CRITICAL``, ``ERROR``, ``WARNING``, ``INFO``, or ``DEBUG``
    ``msg`` (string):
        The message to log
    ``log_type`` (string):
        A dot-separated string identifying the type of the log message
    ``tracekey``:
        A unique key used to track a request through the entire system

    Raises wgen.logger.core.InvalidFieldError is any field contains the field separator
    """
    
    log_line = _format_error_line(
        msg,
        tracekey,
        log_type
    )

    line_length = len(log_line)

    if line_length > LOG_LINE_LIMIT:
        log_line = log_line[0:LOG_LINE_LIMIT]

        errorLogger.warning('Truncating previous log line from {length} to {max_length}'.format(
            length=line_length,
            max_length=LOG_LINE_LIMIT
        ))
    errorLogger.log(severity, log_line, **kwargs)

def debug(msg, log_type, tracekey=None, **kwargs):
    """
    Log a single debug message in the format specified by DDP12
    (http://wiki.wgenhq.net/wiki/index.php/DPP/12#Error_Logs)

    ``msg`` (string):
        The message to log
    ``log_type`` (string):
        A dot-separated string identifying the type of the log message
    ``tracekey``:
        A unique key used to track a request through the entire system

    Raises wgen.logger.core.InvalidFieldError is any field contains the field separator
    """
    log(logging.DEBUG, msg, log_type, tracekey, **kwargs)

def info(msg, log_type, tracekey=None, **kwargs):
    """
    Log a single info message in the format specified by DDP12
    (http://wiki.wgenhq.net/wiki/index.php/DPP/12#Error_Logs)

    ``msg`` (string):
        The message to log
    ``log_type`` (string):
        A dot-separated string identifying the type of the log message
    ``tracekey`` (string):
        A unique key used to track a request through the entire system

    Raises wgen.logger.core.InvalidFieldError is any field contains the field separator
    """
    log(logging.INFO, msg, log_type, tracekey, **kwargs)

def warning(msg, log_type, tracekey=None, **kwargs):
    """
    Log a single warning message in the format specified by DDP12
    (http://wiki.wgenhq.net/wiki/index.php/DPP/12#Error_Logs)

    ``msg`` (string):
        The message to log
    ``log_type`` (string):
        A dot-separated string identifying the type of the log message
    ``tracekey``:
        A unique key used to track a request through the entire system

    Raises wgen.logger.core.InvalidFieldError is any field contains the field separator
    """
    log(logging.WARNING, msg, log_type, tracekey, **kwargs)

warn = warning

def error(msg, log_type, tracekey=None, **kwargs):
    """
    Log a single error message in the format specified by DDP12
    (http://wiki.wgenhq.net/wiki/index.php/DPP/12#Error_Logs)

    ``msg`` (string):
        The message to log
    ``log_type`` (string):
        A dot-separated string identifying the type of the log message
    ``tracekey`` (string):
        A unique key used to track a request through the entire system

    Raises wgen.logger.core.InvalidFieldError is any field contains the field separator
    """
    log(logging.ERROR, msg, log_type, tracekey, **kwargs)

def critical(msg, log_type, tracekey=None, **kwargs):
    """
    Log a single critical message in the format specified by DDP12
    (http://wiki.wgenhq.net/wiki/index.php/DPP/12#Error_Logs)

    ``msg`` (string):
        The message to log
    ``log_type`` (string):
        A dot-separated string identifying the type of the log message
    ``tracekey``:
        A unique key used to track a request through the entire system

    Raises wgen.logger.core.InvalidFieldError is any field contains the field separator
    """
    log(logging.CRITICAL, msg, log_type, tracekey, **kwargs)

def exception(msg, log_type, tracekey=None):
    """
    Log a single error message in the format specified by DDP12
    (http://wiki.wgenhq.net/wiki/index.php/DPP/12#Error_Logs),
    and also logs the stack trace for the currently active exception.
    Note that unlike the other functions this one does NOT take **kwargs
    because the underlying logger.exception() method doesn't accept **kwargs.

    ``msg`` (string):
        The message to log
    ``log_type`` (string):
        A dot-separated string identifying the type of the log message
    ``tracekey``:
        A unique key used to track a request through the entire system

    Raises wgen.logger.core.InvalidFieldError is any field contains the field separator
    """
    log_line = _format_error_line(
        msg,
        tracekey,
        log_type
    )
    errorLogger.exception(log_line)
