"""
This package is a wgen standards compliant logger facade for Python logging.
All logging methods delegate to core.format_log_line which formats and escapes
input to prevent log injection attacks (see https://www.owasp.org/index.php/Log_injection).
"""
