'''
Log formatting code 
'''

from wgen.logger.exception import InvalidFieldError
from wgen.logger.escape import escape

FIELD_SEPARATOR = ' | '
    
def _unicodify(item):
    if item is None:
        return u""
    else:
        return unicode(item)

def format_log_fields(field_list):
    '''
    Returns an escaped log line (unicode string) from generic arguments to the basic logging standard.
    See escape.WHITELIST for our whitelist of characters that aren't escaped.

    Raises InvalidFieldError if any fields contains the field separator
    '''
    str_items = [_unicodify(item) for item in field_list]
    for item in str_items[0:-1]:
        if FIELD_SEPARATOR.strip() in item:
            raise InvalidFieldError("Non-terminal fields cannot contain '{sep}'. Field value is '{item}'".format(sep=FIELD_SEPARATOR.strip(), item=item))

    return (escape(FIELD_SEPARATOR.join(str_items)))
