"""
A set functions for recording auditing information in the style of DPP12
(http://wiki.wgenhq.net/wiki/index.php/DPP/12#Audit_Logs)
"""
from __future__ import absolute_import
from __future__ import with_statement

import logging
from contextlib import contextmanager

from wgen.logger.core import format_log_fields


auditLogger = logging.getLogger('audit')

def _format_audit_line(log_type, username, code_path, url_path, tracekey, message):
    """
    Returns the log line (string) formatting its arguments to the audit logging
    standard (http://wiki.wgenhq.net/wiki/index.php/DPP/12#Audit_Logs)

    ``log_type`` (string):
        A dot-separated identifier of the logging name
    ``username`` (string):
        The name of the user performing the audited action
    ``code_path`` (string):
        An identifier of the auditted code (the full module path and function call name)
    ``url_path`` (string):
        The url being accessed that is triggering this audit call
    ``tracekey``:
        A unique key used to track a request through the entire system
    ``message`` (string):
        Any additional information about actions being taken by the user

    Raises wgen.logger.core.InvalidFieldError is any field contains the field separator
    """
    return format_log_fields(
        [
            log_type,
            username,
            code_path,
            url_path,
            tracekey,
            message,
        ])
    
def audit(log_type, username, message, code_path=None, url_path=None, tracekey=None):
    """
    Writes message to the audit log with additional context of the currently
    logged in user, the controller module, class, and action that are being
    executed, and the request url as specified in the logging standard
    (http://wiki.wgenhq.net/wiki/index.php/DPP/12#Audit_Logs)

    ``log_type`` (string):
        A dot-separated identifier of the logging name
    ``username`` (string):
        The name of the user performing the audited action
    ``message`` (string):
        Any additional information about actions being taken by the user
    ``code_path`` (string):
        An identifier of the auditted code (the full module path and function call name)
    ``tracekey``:
        A unique key used to track a request through the entire system
    ``url_path`` (string):
        The url being accessed that is triggering this audit call

    Raises wgen.logger.core.InvalidFieldError is any field contains the field separator
    """
    log_line = _format_audit_line(
        log_type,
        username,
        code_path,
        url_path,
        tracekey,
        message,
    )
    auditLogger.info(log_line)

@contextmanager
def audited(log_type, username, message, code_path=None, url_path=None, tracekey=None):
    """
    A context manager that audits with supplied message if the contents succeed,
    or audits "Failed: " + message if the contents fail. The audit line is formatted
    in the style of the logging standard (http://wiki.wgenhq.net/wiki/index.php/DPP/12#Audit_Logs)

    ``log_type`` (string):
        A dot-separated identifier of the logging name
    ``username`` (string):
        The name of the user performing the audited action
    ``message`` (string):
        Any additional information about actions being taken by the user
    ``code_path`` (string):
        An identifier of the auditted code (the full module path and function call name)
    ``tracekey``:
        A unique key used to track a request through the entire system
    ``url_path`` (string):
        The url being accessed that is triggering this audit call

    Raises wgen.logger.core.InvalidFieldError is any field contains the field separator
    """
    try:
        yield
    except:
        message = 'FAILED: ' + message
        raise
    finally:
        audit(
            message=message,
            username=username,
            code_path=code_path,
            url_path=url_path,
            log_type=log_type,
            tracekey=tracekey
        )
