from decorator import decorator
import threading
import uuid


_logdata = threading.local()  # This is a thread-local to accomodate mod-wsgi threading
_app_name = None  # This can remain a global (ugh) since there's at most one app name per process


def get_tracekey():
    """
    Return the tracekey currently associated with the calling thread, or None if there isn't one
    """
    if hasattr(_logdata, 'tracekey') and _logdata.tracekey:
        return _logdata.tracekey
    return None


def set_tracekey(tracekey=None):
    """
    Initializes the tracekey to be used for logging messages in the current thread.
    @param tracekey: a tracekey.  If tracekey is None, use a default tracekey.
    """
    if tracekey is None:
        tracekey = _create_unique_id()
    _logdata.tracekey = str(tracekey)


def clear_tracekey():
    """
    Removes the tracekey from the current thread
    """
    _logdata.tracekey = None


def append_tracekey(tracekey=None):
    """
    Append an identifier to the current tracekey in accordance with DPP/17.
    See https://wgencontractorwiki.mc.wgenhq.net/index.php/DPP/17
    """
    tracekey_parts = [
        part for part in [get_tracekey(), tracekey or _create_unique_id()]
        if part is not None
    ]
    set_tracekey('/'.join(map(str, tracekey_parts)))


def append_to_incoming_tracekey(incoming_tracekey, suffix=None):
    """
    Set the tracekey to incoming_tracekey, then append suffix
    """
    set_tracekey(incoming_tracekey)
    append_tracekey(suffix)


def get_app_name():
    """
    Return the app name
    """
    return _app_name


def set_app_name(app_name):
    """
    Set the app name
    """
    global _app_name
    _app_name = app_name


def clear_app_name():
    """
    Clear the app name
    """
    global _app_name
    _app_name = None


def _create_unique_id():
    """
    Creates a random id to be used in a tracekey for DPP/12 logging.
    See https://wgencontractorwiki.mc.wgenhq.net/index.php/DPP/12#Tracekey
    """
    return '_'.join(
        [
            part for part in [get_app_name(), str(uuid.uuid4())]
            if part is not None
        ]
    )
