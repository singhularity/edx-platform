"""
Module for the deprecated decorator.  Use it to mark functions or
methods as deprecated.  For example the below will log a warning:

    >>> @deprecated()
    ... def foo():
    ...     return 5
    >>> foo()
    5
"""
from wgen.logger import logging
from method_decorator import method_decorator

DEFAULT_MSG='Calling deprecated {method_type} {qualified_class_name}.{method_name}'

def deprecated(msg=DEFAULT_MSG):
    '''
    Small decorator that allows you to mark functions or methods as deprecated.
    When the decorated function is called it logs a warning.  Behaves like
    functools.wraps in that it sets the attributes of the deprecated instance
    to match those of the decorated function or method.

    For example:

        >>> class Bar(object):
        ...     def __init__(self, x):
        ...         self.x = x
        ...     @deprecated()
        ...     def square(self):
        ...         return self.x ** 2
        >>> Bar(3).square()
        9
        >>> Bar(3).square.method_type
        'instancemethod'
        >>> Bar(3).square.__name__
        'square'
        >>> Bar(3).square.im_class.__name__
        'Bar'

    deprecated also allows you to specify a custom message:

        >>> class Bar(object):
        ...     def __init__(self, x):
        ...         self.x = x
        ...     @deprecated('Deprecating method {method_name} from class {class_name} in module {module_name}')
        ...     def square(self):
        ...         return self.x ** 2

    The message is a format string.  Available parameters are {module_name}, {class_name},
    {qualified_class_name}, {method_name}, {args}, and {kwargs}.
    '''

    class deprecated_decorator(method_decorator):

        def __call__(self, *args, **kwargs):
            logging.warn(msg.format(
                            method_type=self.method_type,
                            module_name = self.__module__,
                            class_name = self.cls.__name__ if self.cls else None,
                            qualified_class_name='.'.join((self.__module__, self.cls.__name__)) if self.cls
                                                                                                else self.__module__,
                            method_name=self.__name__,
                            args=args,
                            kwargs=kwargs),
                         __name__)
            return method_decorator.__call__(self, *args, **kwargs)

    return deprecated_decorator
