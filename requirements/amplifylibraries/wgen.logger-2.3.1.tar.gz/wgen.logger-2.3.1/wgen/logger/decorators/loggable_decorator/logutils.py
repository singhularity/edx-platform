"""
Helper functions for logging
"""

def get_fully_qualified_method_name(func, args):
    """
    Utility function used by decorators to extract the fully qualified name
    of the method being called. Must be used from within the wrapper that
    replaced the function being decorated.

    @param func: the function being decorated.
    @param args: the arguments passed to func
    """

    if _is_class_or_instance_method(func, args):
        if hasattr(args[0], '__name__'):
            class_name = args[0].__name__
        else:
            class_name = args[0].__class__.__name__
        name_components = (args[0].__module__, class_name, func.__name__)
    else:
        name_components = (func.__module__, func.__name__)

    return ".".join(name_components)


def _is_class_or_instance_method(func, args):
    """
    Determine whether func is actually a class or instance method by examining
    the first argument in args.  We're forced to do this because methods are still
    raw functions at decoration time, so the loggable wrapper has no idea whether
    func is really a method.
    """
    if len(args) > 0:
        def matches_func(fn):
            """
            Does fn match func
            """
            return (
                fn
                and hasattr(fn, 'inner_func') and matches_func(fn.inner_func)
                or isinstance(fn, property) and matches_func(fn.fget)
                or fn is func
            )

        return (
            # First try to get the function from the argument's class, so we don't
            # accidentally execute a property's getter
            (
                hasattr(args[0], '__class__')
                and hasattr(args[0].__class__, func.__name__)
                and matches_func(getattr(args[0].__class__, func.__name__))
            )
            # Otherwise get it directly from the argument (e.g if the argument is an
            # old-style class or a class method)
            or
            (
                hasattr(args[0], func.__name__)
                and matches_func(getattr(args[0], func.__name__))
            )
        )

    return False
