"""
This file is a wrapper around wgen.logger, adding automatic tracekey and log type support.
The WGLog class provides the same set of functions as wgen.logger, except the tracekey is
inserted automatically if not passed in, and the log type will be the value passed to the WGLog
constructor.

To avoid the pain of manually specifying the log type for every log message, the loggable
decorator automatically injects the fully qualified method name as the log type.
"""
from functools import wraps
from decorator import decorator

from wgen.logger import logging as wgen_logging
from wgen.logger.stats import timed as wgen_timed
from wgen.logger.tracekey import get_tracekey

from .logutils import get_fully_qualified_method_name


@decorator
def _tracekey(func, *args, **kwargs):
    if 'tracekey' not in kwargs or kwargs['tracekey'] is None:
        kwargs['tracekey'] = get_tracekey()
    return func(*args, **kwargs)


class WGLog(object):
    """
    Wrapper class around wgen.logger. Each logging method in this class will automatically
    generate a tracekey (if not passed in as a parameter), and set the log type according
    to the constructor parameter.
    """
    def __init__(self, log_type):
        self._log_type = log_type

    @_tracekey
    def info(self, message, **kwargs):
        """
        Delegates to wgen.logger.logging.info
        """
        wgen_logging.info(message, self._log_type, **kwargs)

    @_tracekey
    def debug(self, message, **kwargs):
        """
        Delegates to wgen.logger.logging.debug
        """
        wgen_logging.debug(message, self._log_type, **kwargs)

    @_tracekey
    def warning(self, message, **kwargs):
        """
        Delegates to wgen.logger.logging.warning
        """
        wgen_logging.warning(message, self._log_type, **kwargs)

    @_tracekey
    def error(self, message, **kwargs):
        """
        Delegates to wgen.logger.logging.error
        """
        wgen_logging.error(message, self._log_type, **kwargs)

    @_tracekey
    def critical(self, message, **kwargs):
        """
        Delegates to wgen.logger.logging.critical
        """
        wgen_logging.critical(message, self._log_type, **kwargs)

    @_tracekey
    def exception(self, message, **kwargs):
        """
        Delegates to wgen.logger.logging.exception
        """
        wgen_logging.exception(message, self._log_type, **kwargs)

    @_tracekey
    def timed(self, data_in_units=None, data_out_units=None, extra=None, **kwargs):
        """
        Delegates to wgen.logger.stats.timed
        """
        return wgen_timed(self._log_type, data_in_units, data_out_units, extra, **kwargs)


def loggable(func):
    """
    Decorator for functions which use DPP/12 logging.

    Example usage:

    >>> @loggable
    ... def foo(x, y, logger):
    ...     logger.info('hello world')
    >>> foo(1, 2)

    The third parameter, logger, is passed in automatically. It
    overrides each log method, automatically inserting the log type.

    Result in log type in logs:

    [module].[class].[method]

    """
    @wraps(func)
    def wrapper(*args, **kwargs):
        """
        Passes the logger to the wrapped function
        """
        func_name = get_fully_qualified_method_name(func, args)

        return func(*args, logger=WGLog(func_name), **kwargs)

    wrapper.inner_func = func

    return wrapper
