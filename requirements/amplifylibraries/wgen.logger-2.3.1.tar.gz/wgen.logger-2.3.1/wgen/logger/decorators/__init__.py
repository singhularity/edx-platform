from wgen.logger.decorators.deprecated import deprecated
from wgen.logger.decorators.loggable_decorator import loggable
