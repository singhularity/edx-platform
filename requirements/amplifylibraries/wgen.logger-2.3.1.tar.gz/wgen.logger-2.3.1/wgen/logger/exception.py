class InvalidFieldError(Exception):
    pass
