"""
Whitelist is all printable Latin-1 characters, i.e everything in the Latin-1 block minus
the control characters (code points 00-1F, 7F, and 80-9F).
"""
_WHITELIST = set((unichr(o) for o in range(0x20, 0x7F) + range(0xA0, 0x100)))


def escape(string):
    """
    Return a string with all the non-whitelisted characters escaped.
    ``string`` (string):
        The string to escape
    """
    if set(string).issubset(_WHITELIST):
        return string
    else:
        return "".join((ch if ch in _WHITELIST 
                        else "\\u%04X" % ord(ch)
                        for ch in string))
