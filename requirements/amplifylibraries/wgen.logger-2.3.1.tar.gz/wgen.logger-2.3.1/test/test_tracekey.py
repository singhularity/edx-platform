from unittest import TestCase
from mock import patch, Mock

from wgen.logger.tracekey import (
    get_tracekey,
    set_tracekey,
    clear_tracekey,
    append_tracekey,
    append_to_incoming_tracekey,
    set_app_name,
    get_app_name,
    clear_app_name
)


@patch('uuid.uuid4', Mock(return_value='some_id'))
class TracekeyTests(TestCase):
    def setUp(self):
        clear_tracekey()
        clear_app_name()

    def test_log_none(self):
        """get_tracekey() should return None if no tracekey is set"""
        clear_tracekey()
        self.assertTrue(get_tracekey() is None)

    def test_log_append_tracekey(self):
        """
        get_tracekey should return the incoming tracekey plus a unique id
        """
        set_tracekey('incoming_tracekey')
        append_tracekey()
        self.assertEqual(get_tracekey(), 'incoming_tracekey/some_id')

    def test_append_tracekey_with_tracekey(self):
        """
        get_tracekey returns the incoming tracekey plus the tracekey passed to append_tracekey
        """
        set_tracekey('incoming_tracekey')
        append_tracekey(tracekey="fleebnork")
        self.assertEqual(get_tracekey(), "incoming_tracekey/fleebnork")

    def test_set_tracekey_no_arg(self):
        """
        set_tracekey generates a unique id when called without an argument
        """
        set_tracekey()

        self.assertEqual(get_tracekey(), 'some_id')

    def test_set_tracekey_no_arg_with_app_name(self):
        """
        set_tracekey prepends the app_name to a unique id when called without an argument when app_name is set
        """
        set_app_name('awesomeapp')
        set_tracekey()

        self.assertEqual(get_tracekey(), 'awesomeapp_some_id')

    def test_clear_tracekey(self):
        """
        clear_tracekey removes the tracekey from the current thread
        """
        set_tracekey(tracekey='fleebnork')
        self.assertEqual(get_tracekey(), 'fleebnork')
        clear_tracekey()
        self.assertTrue(get_tracekey() is None)

    def test_append_to_incoming_tracekey(self):
        """
        Append to incoming tracekey appends suffix to the incoming tracekey
        """
        append_to_incoming_tracekey(incoming_tracekey='fleebnork', suffix='macguffin')

    def test_append_to_incoming_tracekey_no_suffix(self):
        """
        Append to incoming tracekey appends a generated suffix to the incoming tracekey if no suffix is given
        """
        append_to_incoming_tracekey(incoming_tracekey='fleebnork')

        self.assertEqual(get_tracekey(), 'fleebnork/some_id')

    def test_set_app_name(self):
        """
        set_app_name sets the app name
        """
        set_app_name('awesomeapp')

        self.assertEqual(get_app_name(), 'awesomeapp')

    def test_clear_app_name(self):
        """
        clear_app_name clears the app name
        """
        set_app_name('awesomeapp')

        self.assertEqual(get_app_name(), 'awesomeapp')

        clear_app_name()

        self.assertTrue(get_app_name() is None)
