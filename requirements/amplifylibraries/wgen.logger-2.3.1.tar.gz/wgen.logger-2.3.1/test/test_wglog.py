"""
Unit tests for wglog
"""
from mock import patch, Mock
from unittest import TestCase

from wgen.logger.tracekey import set_tracekey, clear_tracekey
from wgen.logger.decorators import loggable
from wgen.logger.decorators.loggable_decorator.wglog import WGLog


class LoggableClassyObjectThing:
    '''
    Dummy class that does logging, for testing only
    '''
    def __init__(self):
        pass

    @loggable
    def loggable_instance_method(self, var_a, var_b, logger=None):
        logger.info('hello world')

    @classmethod
    @loggable
    def loggable_class_method(cls, var_a, var_b, logger=None):
        logger.info('hello world')

    @staticmethod
    @loggable
    def loggable_static_method(var_a, var_b, logger=None):
        logger.info('hello world')

    @property
    @loggable
    def loggable_property(self, logger=None):
        logger.info('hello world')


class NewStyleLoggableClassyObjectThing(object):
    '''
    Dummy class that does logging, for testing only
    '''
    @loggable
    def loggable_instance_method(self, var_a, var_b, logger=None):
        logger.info('hello world')

    @classmethod
    @loggable
    def loggable_class_method(cls, var_a, var_b, logger=None):
        logger.info('hello world')

    @staticmethod
    @loggable
    def loggable_static_method(var_a, var_b, logger=None):
        logger.info('hello world')

    @property
    @loggable
    def loggable_property(self, logger=None):
        logger.info('hello world')

    @classmethod
    @loggable
    def mro(cls, var_a, var_b, logger=None):
        """
        Important: has the same name as a method in type. See test_loggable_finds_correct_method
        """
        logger.info('hello world')


@loggable
def loggable_function(var_a, var_b, logger=None):
    logger.info('hello world')


@loggable
def loggable_function_no_args(logger=None):
    logger.info('hello world')


class TestWGLog(TestCase):

    def setUp(self):
        set_tracekey('testtracekey')

    def tearDown(self):
        clear_tracekey()

    def test_debug(self):
        """
        Debug logging should have the correct message, type, and tracekey
        """
        self._test_log('debug')

    def test_info(self):
        """
        Info logging should have the correct message, type, and tracekey
        """
        self._test_log('info')

    def test_warning(self):
        """
        Warning logging should have the correct message, type, and tracekey
        """
        self._test_log('warning')

    def test_error(self):
        """
        Error logging should have the correct message, type, and tracekey
        """
        self._test_log('error')

    def test_critical(self):
        """
        Critical error logging should have the correct message, type, and tracekey
        """
        self._test_log('critical')

    def test_exception(self):
        """
        Exception logging should have the correct message, type, and tracekey
        """
        self._test_log('exception')

    @patch('logging.Logger.info')
    def test_timed(self, fake_info_logger):
        """
        Stats logging should have the correct metric name
        """
        logger = WGLog('fleebnork')
        with logger.timed() as timer:
            pass
        self.assertTrue(fake_info_logger.call_args[0][0].find('fleebnork') >= 0)

    @patch('wgen.logger.logging.info')
    def test_loggable_instance_method_old_style(self, mock_info):
        """
        The loggable decorator should generate the correct log type for instance methods in old-style classes
        """
        expected_log_type = self._get_log_type_old_style('loggable_instance_method')
        loggable_object = LoggableClassyObjectThing()
        loggable_object.loggable_instance_method(1, 2)

        self.assertMockInfoCalledWith(mock_info, 'hello world', expected_log_type, 'testtracekey')

    @patch('wgen.logger.logging.info')
    def test_loggable_class_method_old_style(self, mock_info):
        """
        The loggable decorator should generate the correct log type for class methods in old-style classes
        """
        expected_log_type = self._get_log_type_old_style('loggable_class_method')
        loggable_object = LoggableClassyObjectThing()
        loggable_object.loggable_class_method(1, 2)

        self.assertMockInfoCalledWith(mock_info, 'hello world', expected_log_type, 'testtracekey')

    @patch('wgen.logger.logging.info')
    def test_loggable_static_method_old_style(self, mock_info):
        """
        The loggable decorator should generate the correct log type for static methods in old-style classes
        """
        expected_log_type = self._get_log_type_static('loggable_static_method')
        LoggableClassyObjectThing.loggable_static_method(1, 2)

        self.assertMockInfoCalledWith(mock_info, 'hello world', expected_log_type, 'testtracekey')

    @patch('wgen.logger.logging.info')
    def test_loggable_property_old_style(self, mock_info):
        """
        The loggable decorator should generate the correct log type for properties in old-style classes
        """
        expected_log_type = self._get_log_type_old_style('loggable_property')
        loggable_object = LoggableClassyObjectThing()
        loggable_object.loggable_property

        self.assertMockInfoCalledWith(mock_info, 'hello world', expected_log_type, 'testtracekey')

    @patch('wgen.logger.logging.info')
    def test_loggable_instance_method_new_style(self, mock_info):
        """
        The loggable decorator should generate the correct log type for instance methods in new-style classes
        """
        expected_log_type = self._get_log_type_new_style('loggable_instance_method')
        loggable_object = NewStyleLoggableClassyObjectThing()
        loggable_object.loggable_instance_method(1, 2)

        self.assertMockInfoCalledWith(mock_info, 'hello world', expected_log_type, 'testtracekey')

    @patch('wgen.logger.logging.info')
    def test_loggable_class_method_new_style(self, mock_info):
        """
        The loggable decorator should generate the correct log type for class methods in new-style classes
        """
        expected_log_type = self._get_log_type_new_style('loggable_class_method')
        loggable_object = NewStyleLoggableClassyObjectThing()
        loggable_object.loggable_class_method(1, 2)

        self.assertMockInfoCalledWith(mock_info, 'hello world', expected_log_type, 'testtracekey')

    @patch('wgen.logger.logging.info')
    def test_loggable_static_method_new_style(self, mock_info):
        """
        The loggable decorator should generate the correct log type for static methods in new-style classes
        """
        expected_log_type = self._get_log_type_static('loggable_static_method')
        NewStyleLoggableClassyObjectThing.loggable_static_method(1, 2)

        self.assertMockInfoCalledWith(mock_info, 'hello world', expected_log_type, 'testtracekey')

    @patch('wgen.logger.logging.info')
    def test_loggable_property_new_style(self, mock_info):
        """
        The loggable decorator should generate the correct log type for properties in new-style classes
        """
        expected_log_type = self._get_log_type_new_style('loggable_property')
        loggable_object = NewStyleLoggableClassyObjectThing()
        loggable_object.loggable_property

        self.assertMockInfoCalledWith(mock_info, 'hello world', expected_log_type, 'testtracekey')

    @patch('wgen.logger.logging.info')
    def test_loggable_function(self, mock_info):
        """
        The loggable decorator should generate the correct log type for regular functions with arguments
        """
        expected_log_type = self._get_log_type_static('loggable_function')
        loggable_function(1, 2)

        self.assertMockInfoCalledWith(mock_info, 'hello world', expected_log_type, 'testtracekey')

    @patch('wgen.logger.logging.info')
    def test_loggable_function_no_args(self, mock_info):
        """
        The loggable decorator should generate the correct log type for regular functions without arguments
        """
        expected_log_type = 'test_wglog.loggable_function_no_args'
        loggable_function_no_args()

        self.assertMockInfoCalledWith(mock_info, 'hello world', expected_log_type, 'testtracekey')

    @patch('wgen.logger.logging.info')
    def test_loggable_finds_correct_method(self, mock_info):
        """
        The loggable decorator should find the correct method even if the method name is the same as a method in the built-in type class
        """
        expected_log_type = self._get_log_type_new_style('mro')
        NewStyleLoggableClassyObjectThing.mro(1, 2)

        self.assertMockInfoCalledWith(mock_info, 'hello world', expected_log_type, 'testtracekey')

    logging_setup = False

    @loggable
    def test_0loggable_setup(self, logger):
        """
        Not a real test; this sets self.foo = True, so that test_loggable_does_not_hide_tests can assert that this test isn't skipped
        """
        self.__class__.logging_setup = True

    def test_loggable_does_not_hide_tests(self):
        """
        Asserts that tagging tests as loggable doesn't break test detection
        """
        self.assertTrue(self.logging_setup)

    def test_loggable_does_not_break_docstring(self):
        """
        Asserts that tagging tests as loggable doesn't change the docstring
        """
        @loggable
        def whats_up_doc(logger):
            """docstring"""
            pass
        self.assertEqual(whats_up_doc.__doc__, "docstring")

    def test_loggable_preserves_function_name(self):
        """
        Asserts that tagging tests as loggable doesn't change the function name
        """
        @loggable
        def funky_monkey(logger):
            pass
        self.assertEqual(funky_monkey.__name__, "funky_monkey")

    def assertMockInfoCalledWith(self, mock_info, message, log_type, tracekey):
        """
        Asserts that the mock info method was called with message and log_type as
        positional args and with the tracekey as a keyword arg.
        """
        self.assertEqual(
            mock_info.call_args[0],
            (message, log_type)
        )
        self.assertEqual(
            mock_info.call_args[1].get('tracekey'),
            tracekey
        )

    def _test_log(self, log_type):
        '''
        Abstraction of the process of calling a log method and checking the result
        '''
        with patch('wgen.logger.logging.' + log_type) as mock_logger_method:
            getattr(WGLog('log_type'), log_type)('message')
            self.assertEqual(mock_logger_method.call_args[0], ('message', 'log_type'))
            self.assertEqual(mock_logger_method.call_args[1].get('tracekey'), 'testtracekey')

    @staticmethod
    def _get_log_type_old_style(method):

        return '.'.join((__name__,
                         LoggableClassyObjectThing.__name__,
                         method))

    @staticmethod
    def _get_log_type_new_style(method):

        return '.'.join((__name__,
                         NewStyleLoggableClassyObjectThing.__name__,
                         method))

    @staticmethod
    def _get_log_type_static(method):

        return '.'.join((__name__, method))
