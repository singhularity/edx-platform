"""
NAPI Client Exceptions
"""

import httplib
import simplejson as json


class NapiRuntimeError(Exception):
    pass


class NapiErrorRuntimeError(NapiRuntimeError):
    """
    NAPI server error occurred
    """
    def __init__(self, error_code, error_type, error_msg, stack, sub_error_codes):
        """
        Constructor.

        @param error_msg: a verbose message that can be logged or displayed to the user
        @param error_code: a brief error code that's useful for programs analyzing an error
        @param error_type: an error type that's useful for programs analyzing an error
        @param stack: an error stacktrace that can be used to analyze the error
        @param sub_error_codes: list of error codes associated with the main error_code
        """
        self.error_msg = error_msg
        self.error_type = error_type
        self.stack = stack
        self.error_code = error_code
        self.sub_error_codes = sub_error_codes

    def __str__(self):
        """
        Return string representation of the error for error debugging.
        @return: institution_uid that this staff belongs to
        """
        message = "A NAPI Error occurred:\n"
        message += "Error code: %s\n" % self.error_code
        message += "Error type: %s\n" % self.error_type
        message += "Error message: %s\n" % self.error_msg
        message += "Sub error codes: %s\n" % self.sub_error_codes
        message += "Python Stack trace: %s\n" % self.stack
        return message


# pylint: disable=W0613
def raise_potential_napi_error(self, http_conn_error, status_expected):
    """
    Checks that NAPI's response contains the expected http status code.  Will throw a
    NapiRuntimeException with detailed information if a different status was returned.

    @param http_conn_error: http connection error object generated
    @param status_expected: expected status of response
    """
    http_code = http_conn_error.status_code
    if http_code != status_expected:
        if http_code in (httplib.FORBIDDEN, httplib.UNAUTHORIZED):
            raise NapiRuntimeError(http_conn_error.error_msg)
        try:
            response_json = json.loads(http_conn_error.response_body)
            if 'error_code' in response_json:
                raise NapiErrorRuntimeError(response_json["error_code"],
                                            response_json["error_type"],
                                            response_json["error_message"],
                                            response_json["stack"],
                                            response_json["sub_error_codes"])
        except NapiErrorRuntimeError:
            raise
        except Exception, exc:
            raise NapiRuntimeError("An error occurred parsing NAPI's error response. Exception: [%s]" % exc)
