"""
Enrollment API Client
See wiki for NAPI Interface documentation:
http://wiki.wgenhq.net/wiki/index.php/Enrollment/Enrollment_API/UserDocumentation

NB: There is a known bug in wgen.httpconn which requires strings to be
    wrapped in a list to avoid being turned into csv of chars.
    Example: "goose" -> "g,o,o,s,e" vs. ["goose"] -> "goose"
"""

import httplib
import simplejson as json
import logging

from csv import reader
from wgen.httpconn import HttpConnectionError

from napiclient.errors import raise_potential_napi_error


# NAPI tracekey parameters
URL_PARAM_TRACEKEY = "tracekey"

# NAPI UID parameters
URL_PARAM_ACCOUNT_UID = "account_uid"
URL_PARAM_ACCOUNT_UIDS = "account_uids"
URL_PARAM_CLASSE_UIDS = "classe_uids"
URL_PARAM_INSTITUTION_UIDS = "institution_uids"
URL_PARAM_STAFF_UIDS = "staff_uids"
URL_PARAM_STUDENT_UIDS = "student_uids"
URL_PARAM_SUBJECT_AREA_UIDS = "subject_area_uids"
URL_PARAM_COURSE_UIDS = "course_uids"
URL_PARAM_COURSE_ENROLLMENT_UIDS = "course_enrollment_uids"
URL_PARAM_ROOT_INST_UID = "root_inst_uid"

# NAPI String parameters
URL_PARAM_EMAIL = "email_address"
URL_PARAM_FIRST_NAME = "first_name"
URL_PARAM_LAST_NAME = "last_name"
URL_PARAM_TITLE = "title"
URL_PARAM_GRADE = "grade"
URL_PARAM_PHONE = "phone"
URL_PARAM_FAX = "fax"

# NAPI Flag parameters
URL_PARAM_WITH_APPLICATIONS = "with_applications"
URL_PARAM_WITH_CONFIGS = "with_configs"
URL_PARAM_WITH_CUSTOMATTRIBS = "with_customattribs"
URL_PARAM_WITH_DEMOGRAPHICS = "with_demographics"
URL_PARAM_WITH_GRADEYEAR = "with_allgrades"
URL_PARAM_WITH_GROUPS = "with_groups"
URL_PARAM_WITH_NO_DEMO_STUDENTS = 'with_no_demo_students'
URL_PARAM_WITH_SCHOOL_YEAR = "school_year"
URL_PARAM_WITH_STUDENTS = "with_students"

# NAPI Value parameters
URL_PARAM_CHANGED_SINCE = "changed_since"
URL_PARAM_SYNC_SESSION_STATUS = "sync_session_status"

FLAG_TRUE = "1"

# NAPI Server Paths

VIEWS_URLS = {
    "accounts": "/views/accounts",
    "all_accounts": "/views/accounts/all",
    "all_applications": "/views/applications/all",
    "my_account": "/views/accounts/my",
    "my_apps_and_addons": "/views/apps_addons/my",
    "all_apps_and_addons": "/views/apps_addons/all",
    "classe_staff_delta": "/views/classe_staff/delta",
    "classe_students_delta": "/views/classe_students/delta",
    "classes": "/views/classes",
    "classes_delta": "/views/classes/delta",
    "courses": "/views/courses",
    "my_courses": "/views/courses/my",
    "institutions": "/views/institutions",
    "mCLASS_Years": "/views/mclass_years",
    "my_institution_hierarchy": "/views/my_institution_hierarchy",
    "staff": "/views/staff",
    "staff_delta": "/views/staff/delta",
    "my_staff_categories": "/views/staff_categories/my",
    "students": "/views/students",
    "students_csv": "/views/students/csv",
    "students_internal": "/views/students/internal",
    "students_delta": "/views/students/delta",
    "all_subjects": "/views/subjects/all",
    "my_subjects": "/views/subjects/my",
}
RESOURCE_URLS = {
    "account": "/resource/account/{account_uid}",
    "staff": "/resource/staff/{staff_uid}",
    "sync_session": "/resource/sync_session"
}

LOGGER = logging.getLogger(__name__)


class NapiClient(object):
    """
    A client for interacting with the NAPI Service.  One Client should
    be created for each connection with an Individual NAPI Host.
    """

    def __init__(self, http_conn):
        self._http_conn = http_conn

    @staticmethod
    def _tracekey_dict(tracekey):
        return {} if not tracekey else {URL_PARAM_TRACEKEY: tracekey}

    @staticmethod
    def _fill_flags(args):
        """
        Make a dictionary of `key: FLAG_TRUE` pairs if the `test` value is truth-y
        """
        return dict((key, FLAG_TRUE) for key, test in args if test)

    @staticmethod
    def _fill_values(args):
        """
        Make a dictionary of `key: value` pairs if `value` is truth-y
        """
        return dict((key, value) for key, value in args if value)

    def _get_view(self, view_url, params):
        """
        Get information about a given Entity. The information comes from the
        NAPI server. Please see the server documentation for up-to-date
        information about what is being sent.

        @param view_url: A URL for the entity from where view will be retrieved.
        @param params: A dictionary for the filtering options
        @return: The list of Entities found by the NAPI Server.
        """
        try:
            if URL_PARAM_TRACEKEY in params:
                params[URL_PARAM_TRACEKEY] = self._conv_str_to_list(params[URL_PARAM_TRACEKEY])
            response = self._http_conn.get(view_url, params)
        except HttpConnectionError, exc:
            LOGGER.exception(exc)
            raise_potential_napi_error(self, exc, httplib.OK)
        except Exception, e:
            LOGGER.exception(e)
            raise e
        return response

    def _get_json_view(self, view_url, params):
        """
        Get information about a given Entity in JSON format.

        @param view_url: A URL for the entity from where view will be retrieved.
        @param params: A dictionary for the filtering options
        @return: The JSON-encoded list of Entities found by the NAPI Server.
        """
        # Load json into array and return
        return json.load(self._get_view(view_url, params))

    def _get_csv_view(self, view_url, params):
        """
        Get information about a given Entity in CSV format.

        @param view_url: A URL for the entity from where view will be retrieved.
        @param params: A dictionary for the filtering options
        @return: The csv.reader for the Entities found by the NAPI Server.
        """
        # Returns reader for csv
        return reader(self._get_view(view_url, params))

    def _get_resource(self, resource_url, params):
        """
        Get the specified resource with data in the given parameters.

        @param resource_url: A URL for the resource to be updated.
        @param params: A dictionary with data to PUT to resource.
        """
        try:
            if URL_PARAM_TRACEKEY in params:
                params[URL_PARAM_TRACEKEY] = self._conv_str_to_list(params[URL_PARAM_TRACEKEY])
            response = self._http_conn.get(resource_url, params)
        except HttpConnectionError, exc:
            LOGGER.exception(exc)
            raise_potential_napi_error(self, exc, httplib.OK)
        except Exception, e:
            LOGGER.exception(e)
            raise e
        # Load json into array and return
        return json.load(response)

    def _post_resource(self, resource_url, params):
        """
        Create the specified resource with data in the given parameters.

        @param resource_url: A URL for the resource to be updated.
        @param params: A dictionary with data to PUT to resource.
        """
        try:
            if URL_PARAM_TRACEKEY in params:
                params[URL_PARAM_TRACEKEY] = self._conv_str_to_list(params[URL_PARAM_TRACEKEY])
            return self._http_conn.post(resource_url, params)
        except HttpConnectionError, exc:
            LOGGER.exception(exc)
            raise_potential_napi_error(self, exc, httplib.OK)
        except Exception, e:
            LOGGER.exception(e)
            raise e

    def _put_resource(self, resource_url, params):
        """
        Update the specified resource with data in the given parameters.

        @param resource_url:A URL for the resource to be updated.
        @param params: A dictionary with data to PUT to resource.
        """
        try:
            if URL_PARAM_TRACEKEY in params:
                params[URL_PARAM_TRACEKEY] = self._conv_str_to_list(params[URL_PARAM_TRACEKEY])
            self._http_conn.put(resource_url, params)
        except HttpConnectionError as exc:
            LOGGER.exception(exc)
            raise_potential_napi_error(self, exc, httplib.OK)
        except Exception as ex:
            LOGGER.exception(ex)
            raise ex

    def _conv_str_to_list(self, param):
        """
        If the param is a string, return a list with the string as the
        only element. Otherwise return the param.

        This is to deal with the bug in the httpconn library which converts
        all param values to csv lists. Great for uids in a list, bad for
        string literals like tracekeys!

        @param Hopefully a string. But you can pass in anything.
        """
        return [param] if isinstance(param, basestring) else param

    def all_accounts_view(self, tracekey=None):
        """
        Get information about All Accounts. The information comes from the
        NAPI server. Please see the server documentation for up-to-date
        information about what is being sent.

        @param tracekey: (optional) execution tracekey
        @return: The list of All Active Accounts found by the NAPI Server.
        """
        params = self._tracekey_dict(tracekey)
        url = VIEWS_URLS["all_accounts"]
        return self._get_json_view(url, params)

    def all_applications_view(self, tracekey=None):
        """
        Get information about All Applications. The information comes from the
        NAPI server. Please see the server documentation for up-to-date
        information about what is being sent.

        @param tracekey: (optional) execution tracekey
        @return: The list of All Active Accounts found by the NAPI Server.
        """
        params = self._tracekey_dict(tracekey)
        url = VIEWS_URLS["all_applications"]
        return self._get_json_view(url, params)

    def my_accounts_view(self, with_customattribs=False, tracekey=None):
        """
        Get information about My Account. The information comes from the
        NAPI server. Please see the server documentation for up-to-date
        information about what is being sent.

        @param with_customattribs:  (optional) boolean flag that determines whether
                    or not to return customattribs data. Default False.
        @param tracekey: (optional) execution tracekey
        @return: The list of Accounts found by the NAPI Server.
        """
        params = self._tracekey_dict(tracekey)
        flags = [
            (URL_PARAM_WITH_CUSTOMATTRIBS, with_customattribs),
        ]
        params.update(self._fill_flags(flags))
        return self._get_json_view(VIEWS_URLS["my_account"], params)

    def accounts_view(self, institution_uids=None, with_customattribs=False, tracekey=None):
        """
        Get information about Accounts. The information comes from the
        NAPI server. Please see the server documentation for up-to-date
        information about what is being sent.

        @param institution_uids: A list of Institution UIDS to filter Accounts by.
        @param with_customattribs:  (optional) boolean flag that determines whether
                          or not to return customattribs data. Default False.
        @param tracekey: (optional) execution tracekey
        @return: The list of Accounts found by the NAPI Server.
        """
        params = {URL_PARAM_INSTITUTION_UIDS: institution_uids or []}
        flags = [
            (URL_PARAM_WITH_CUSTOMATTRIBS, with_customattribs),
        ]
        params.update(self._fill_flags(flags))
        params.update(self._tracekey_dict(tracekey))
        url = VIEWS_URLS["accounts"]
        return self._get_json_view(url, params)

    def classe_view(self, classe_uids=None, staff_uids=None, institution_uids=None,
                    with_students=False, with_groups=False, school_year=None,
                    tracekey=None):
        """
        Get information about a given Class. The information comes from the
        NAPI server. Please see the server documentation for up-to-date
        information about what is being sent.

        @param classe_uids: A list of Classe UIDS to filter Classes by.
        @param staff_uids: A list of Staff UIDS to filter Classes by.
        @param institution_uids: A list of Institution UIDS to filter Classes by.
        @param with_students: (optional) boolean flag that determines whether
                          or not to return student data. Default False.
        @param with_groups: (optional) boolean flag that determines whether
                          or not to return group data. Default False.
        @param school_year: (optional) the year for which we want classes
                         Default: None (this will return whatever school_year is current)
        @param tracekey: (optional) execution tracekey
        @return: The list of Classes found by the NAPI Server.
        """
        params = {
            URL_PARAM_CLASSE_UIDS: classe_uids or [],
            URL_PARAM_STAFF_UIDS: staff_uids or [],
            URL_PARAM_INSTITUTION_UIDS: institution_uids or [],
        }

        flags = [
            (URL_PARAM_WITH_STUDENTS, with_students),
            (URL_PARAM_WITH_GROUPS, with_groups),
        ]
        params.update(self._fill_flags(flags))

        values = [
            (URL_PARAM_WITH_SCHOOL_YEAR, school_year),
            (URL_PARAM_TRACEKEY, tracekey),
        ]
        params.update(self._fill_values(values))

        url = VIEWS_URLS["classes"]
        return self._get_json_view(url, params)

    def classe_delta_view(self, account_uids=None, changed_since=None,
                          with_groups=False, school_year=None, tracekey=None):
        """
        Get information about Class Deltas. The information comes from the
        NAPI server. Please see the server documentation for up-to-date
        information about what is being sent.

        @param account_uids: A list of Account UIDS to filter Classes by.
        @param changed_since: A after which to calculate deltas
        @param with_groups: (optional) boolean flag that determines whether
                          or not to return group data. Default False.
        @param school_year: (optional) the year for which we want classes
                         Default: None (this will return whatever school_year is current)
        @param tracekey: (optional) execution tracekey
        @return: The list of Classes found by the NAPI Server.
        """
        params = {
            URL_PARAM_ACCOUNT_UIDS: account_uids or [],
            URL_PARAM_CHANGED_SINCE: changed_since,
        }

        flags = [
            (URL_PARAM_WITH_GROUPS, with_groups),
        ]
        params.update(self._fill_flags(flags))

        values = [
            (URL_PARAM_WITH_SCHOOL_YEAR, school_year),
            (URL_PARAM_TRACEKEY, tracekey),
        ]
        params.update(self._fill_values(values))

        url = VIEWS_URLS["classes_delta"]
        return self._get_json_view(url, params)

    def classe_staff_delta_view(self, account_uids=None, changed_since=None,
                                tracekey=None):
        """
        Get information about Class Staff Deltas. The information comes from the
        NAPI server. Please see the server documentation for up-to-date
        information about what is being sent.

        @param account_uids: A list of Account UIDS to filter Classes by.
        @param changed_since: A after which to calculate deltas
        @param tracekey: (optional) execution tracekey
        @return: The list of Classes found by the NAPI Server.
        """
        params = {
            URL_PARAM_ACCOUNT_UIDS: account_uids or [],
            URL_PARAM_CHANGED_SINCE: changed_since,
        }
        params.update(self._tracekey_dict(tracekey))
        url = VIEWS_URLS["classe_staff_delta"]
        return self._get_json_view(url, params)

    def classe_students_delta_view(self, account_uids=None, changed_since=None,
                                   tracekey=None):
        """
        Get information about Class Student Deltas. The information comes from the
        NAPI server. Please see the server documentation for up-to-date
        information about what is being sent.

        @param account_uids: A list of Account UIDS to filter Classes by.
        @param changed_since: A after which to calculate deltas
        @param tracekey: (optional) execution tracekey
        @return: The list of Classes found by the NAPI Server.
        """
        params = {
            URL_PARAM_ACCOUNT_UIDS: account_uids or [],
            URL_PARAM_CHANGED_SINCE: changed_since,
        }
        params.update(self._tracekey_dict(tracekey))
        url = VIEWS_URLS["classe_students_delta"]
        return self._get_json_view(url, params)

    def staff_view(self, staff_uids=None, institution_uids=None, email_address=None, tracekey=None):
        """
        Get information about Staff. The information comes from the
        NAPI server. Please see the server documentation for up-to-date
        information about what is being sent.

        @param staff_uids: A list of Staff UIDS to filter Staff by.
        @param institution_uids: A list of Institution UIDS to filter Staff by.
        @param email_address: (optional) an email address to filter Staff by.
        @param tracekey: (optional) execution tracekey
        @return: The list of Staff found by the NAPI Server.
        """
        params = {
            URL_PARAM_STAFF_UIDS: staff_uids or [],
            URL_PARAM_INSTITUTION_UIDS: institution_uids or [],
        }
        params.update(self._tracekey_dict(tracekey))
        if email_address:
            params[URL_PARAM_EMAIL] = [email_address]
        url = VIEWS_URLS["staff"]
        return self._get_json_view(url, params)

    def staff_deltas_view(self, account_uids=None, changed_since=None, tracekey=None):
        """
        Get information about Staff Deltas. The information comes from the
        NAPI server. Please see the server documentation for up-to-date
        information about what is being sent.

        @param account_uids: A list of Account UIDS to filter Classes by.
        @param changed_since: A after which to calculate deltas
        @param tracekey: (optional) execution tracekey
        @return: The list of Staff Deltas found by the NAPI Server.
        """
        params = {
            URL_PARAM_ACCOUNT_UIDS: account_uids,
            URL_PARAM_CHANGED_SINCE: changed_since
        }
        if tracekey:
            params[URL_PARAM_TRACEKEY] = tracekey
        url = VIEWS_URLS["staff_delta"]
        return self._get_json_view(url, params)

    def mclass_years_view(self, tracekey=None):
        """
        Get information about mCLASS Years. The information comes from the
        NAPI server. Please see the server documentation for up-to-date
        information about what is being sent.

        @param tracekey: (optional) execution tracekey
        @return: The list of mCLASS Years found by the NAPI Server.
        """
        params = self._tracekey_dict(tracekey)
        url = VIEWS_URLS["mCLASS_Years"]
        return self._get_json_view(url, params)

    def my_staff_categories_view(self, tracekey=None):
        """
        Get information about the Staff Categories for the current user. The
        information comes from the NAPI server. Please see the server
        documentation for up-to-date information about what is being sent.

        @param tracekey: (optional) execution tracekey
        @return: The list of Staff Categories found by the NAPI Server.
        """
        params = self._tracekey_dict(tracekey)
        url = VIEWS_URLS["my_staff_categories"]
        return self._get_json_view(url, params)

    def my_subjects_view(self, tracekey=None):
        """
        Get information about the subjects configured for my account. The
        information comes from the NAPI server. Please see the server
        documentation for up-to-date information about what is being sent.
        @param tracekey: (optional) execution tracekey
        @return: The list of Subjects configured for the account.
        """
        params = self._tracekey_dict(tracekey)
        return self._get_json_view(VIEWS_URLS["my_subjects"], params)

    def all_subjects_view(self, tracekey=None):
        """
        Get all subjects available in database.
        The information comes from the NAPI server. Please see the server
        documentation for up-to-date information about what is being sent.
        @param tracekey: (optional) execution tracekey
        @return: The list of all available Subjects.
        """
        params = self._tracekey_dict(tracekey)
        return self._get_json_view(VIEWS_URLS["all_subjects"], params)

    def inst_view(self, institution_uids=None, with_applications=False, school_year=None, tracekey=None):
        """
        Get information about Institutions. The information comes from the
        NAPI server. Please see the server documentation for up-to-date
        information about what is being sent.

        @param institution_uids: A list of Institution UIDS to filter Institution by.
        @param with_applications: (optional) boolean flag that determines whether
                          or not to return licensing data. Default False.
        @param school_year: (optional) the year for which we want institutions
                         Default: None (this will return whatever school_year is current)
        @param tracekey: (optional) execution tracekey
        @return: The list of Institutions found by the NAPI Server.
        """
        params = {
            URL_PARAM_INSTITUTION_UIDS: institution_uids or [],
        }

        flags = [
            (URL_PARAM_WITH_APPLICATIONS, with_applications),
        ]
        params.update(self._fill_flags(flags))

        values = [
            (URL_PARAM_WITH_SCHOOL_YEAR, school_year),
            (URL_PARAM_TRACEKEY, tracekey),
        ]
        params.update(self._fill_values(values))

        url = VIEWS_URLS["institutions"]
        return self._get_json_view(url, params)

    # TODO: Once versioning in NAPI is implemented, re-arrange the parameters here.
    def students_view(self,
                      student_uid_list=None, classe_uids=None,
                      with_allgrades=False, with_demographics=False,
                      with_no_demo_students=False, school_year=None, tracekey=None,
                      account_uid=None, root_inst_uid=None):
        """
        Get information about Students. The information comes from the
        NAPI server. Please see the server documentation for up-to-date
        information about what is being sent.

        @param account_uid: An account UID to filter by
        @param root_inst_uid: A root-inst-UID to filter by
        @param student_uid_list: A list of Student UIDS to filter by.
        @param classe_uids: A list of Classe UIDS to filter by
        @param with_allgrades: (optional) boolean flag to get all active enrollments
                            in all years in which the student(s) are/were enrolled.
        @param with_no_demo_students: (optional) boolean flag to filter out all
                            demo students.
        @param school_year: (optional) the year for which we want students
                         Default: None (this will return whatever school_year is current)
        @param tracekey: (optional) execution tracekey
        @return: The list of Students found by the NAPI Server.
        """
        params = {
            URL_PARAM_STUDENT_UIDS: student_uid_list or [],
            URL_PARAM_CLASSE_UIDS: classe_uids or [],
            URL_PARAM_ACCOUNT_UID: account_uid or [],
            URL_PARAM_ROOT_INST_UID: root_inst_uid or [],
        }

        flags = [
            (URL_PARAM_WITH_GRADEYEAR, with_allgrades),
            (URL_PARAM_WITH_NO_DEMO_STUDENTS, with_no_demo_students),
            (URL_PARAM_WITH_DEMOGRAPHICS, with_demographics),
        ]
        params.update(self._fill_flags(flags))

        values = [
            (URL_PARAM_WITH_SCHOOL_YEAR, school_year),
            (URL_PARAM_TRACEKEY, tracekey),
        ]
        params.update(self._fill_values(values))

        url = VIEWS_URLS["students"]
        return self._get_json_view(url, params)

    # TODO: Once versioning in NAPI is implemented, re-arrange the parameters here.
    def students_csv_view(self,
                          student_uid_list=None, classe_uids=None,
                          with_allgrades=False, with_demographics=False,
                          with_no_demo_students=False, school_year=None,
                          tracekey=None,
                          account_uid=None, root_inst_uid=None):
        """
        Identical to students_view(), but data is returned in CSV format.

        @param account_uid: An account UID to filter by
        @param root_inst_uid: A root-inst-UID to filter by
        @param student_uid_list: A list of Student UIDS to filter by.
        @param classe_uids: A list of Classe UIDS to filter by
        @param with_allgrades: (optional) boolean flag to get all active enrollments
                            in all years in which the student(s) are/were enrolled.
        @param with_no_demo_students: (optional) boolean flag to filter out all
                            demo students.
        @param school_year: (optional) the year for which we want students
                         Default: None (this will return whatever school_year is current)
        @param tracekey: (optional) execution tracekey
        @return: A csv.DictReader for the Students found by the NAPI Server.
        """
        params = {
            URL_PARAM_STUDENT_UIDS: student_uid_list or [],
            URL_PARAM_CLASSE_UIDS: classe_uids or [],
            URL_PARAM_ACCOUNT_UID: account_uid or [],
            URL_PARAM_ROOT_INST_UID: root_inst_uid or [],
        }

        flags = [
            (URL_PARAM_WITH_GRADEYEAR, with_allgrades),
            (URL_PARAM_WITH_NO_DEMO_STUDENTS, with_no_demo_students),
            (URL_PARAM_WITH_DEMOGRAPHICS, with_demographics),
        ]
        params.update(self._fill_flags(flags))

        values = [
            (URL_PARAM_WITH_SCHOOL_YEAR, school_year),
            (URL_PARAM_TRACEKEY, tracekey),
        ]
        params.update(self._fill_values(values))

        url = VIEWS_URLS["students_csv"]
        return self._get_csv_view(url, params)

    # TODO: Once versioning in NAPI is implemented, re-arrange the parameters here.
    def students_internal_view(self,
                               student_uid_list=None, classe_uids=None,
                               with_allgrades=False, with_demographics=False,
                               with_no_demo_students=False, school_year=None, tracekey=None,
                               account_uid=None, root_inst_uid=None):
        """
        Get information about Students. The information comes from the
        NAPI server. Please see the server documentation for up-to-date
        information about what is being sent.

        @param account_uid: An account UID to filter by
        @param root_inst_uid: A root-inst-UID to filter by
        @param student_uid_list: A list of Student UIDS to filter by.
        @param classe_uids: A list of Classe UIDS to filter by
        @param with_allgrades: (optional) boolean flag to get all active enrollments
                            in all years in which the student(s) are/were enrolled.
        @param with_no_demo_students: (optional) boolean flag to filter out all
                            demo students.
        @param school_year: (optional) the year for which we want students
                         Default: None (this will return whatever school_year is current)
        @param tracekey: (optional) execution tracekey
        @return: The list of Students found by the NAPI Server.
        """
        params = {
            URL_PARAM_STUDENT_UIDS: student_uid_list or [],
            URL_PARAM_CLASSE_UIDS: classe_uids or [],
            URL_PARAM_ACCOUNT_UID: account_uid or [],
            URL_PARAM_ROOT_INST_UID: root_inst_uid or [],
        }

        flags = [
            (URL_PARAM_WITH_GRADEYEAR, with_allgrades),
            (URL_PARAM_WITH_NO_DEMO_STUDENTS, with_no_demo_students),
            (URL_PARAM_WITH_DEMOGRAPHICS, with_demographics),
        ]
        params.update(self._fill_flags(flags))

        values = [
            (URL_PARAM_WITH_SCHOOL_YEAR, school_year),
            (URL_PARAM_TRACEKEY, tracekey),
        ]
        params.update(self._fill_values(values))

        url = VIEWS_URLS["students_internal"]
        return self._get_json_view(url, params)

    def students_delta_view(self, account_uid_list=None, changed_since=None,
                            tracekey=None):
        """
        Get information about Student Deltas. The information comes from the
        NAPI server. Please see the server documentation for up-to-date
        information about what is being sent.

        @param account_uid_list: A list of Account UIDS to filter by.
        @param changed_since: A after which to calculate deltas
        @param tracekey: (optional) execution tracekey
        @return: The list of Students found by the NAPI Server.
        """
        params = {
            URL_PARAM_ACCOUNT_UIDS: account_uid_list or [],
            URL_PARAM_CHANGED_SINCE: changed_since,
        }

        flags = [
        ]
        params.update(self._fill_flags(flags))

        params.update(self._tracekey_dict(tracekey))
        url = VIEWS_URLS["students_delta"]
        return self._get_json_view(url, params)

    def my_inst_hierarchy_view(self, account_uid=None, school_year=None,
                               with_configs=False, with_customattribs=False,
                               tracekey=None):
        """Get basic information about institutions in account in a hierarchy.

        The information comes from the NAPI server. Please see the server
        documentation for up-to-date information about what is being sent.

        @param account_uid: (optional) UID of account whose institutions to get
            Default: None (this will return all institutions in the
            authenticated user's account)
        @param school_year: (optional) year in SIF format for which we want
            institutions Default: None (this will return whatever school_year is
            current)
        @param with_configs: (optional) boolean flag to include id, demog config
            info Default: False
        @param with_customattribs: (optional) boolean flag to include
            customattrib configuration Default: False
        @param tracekey: (optional) execution tracekey
        @return: The list of active Institutions found by the NAPI Server.
        """
        values = [
            (URL_PARAM_WITH_SCHOOL_YEAR, school_year),
            (URL_PARAM_ACCOUNT_UID, account_uid),
            (URL_PARAM_TRACEKEY, tracekey),
        ]
        params = self._fill_values(values)

        flags = [
            (URL_PARAM_WITH_CONFIGS, with_configs),
            (URL_PARAM_WITH_CUSTOMATTRIBS, with_customattribs)
        ]
        params.update(self._fill_flags(flags))

        url = VIEWS_URLS["my_institution_hierarchy"]
        return self._get_json_view(url, params)

    def my_apps_addons_view(self, tracekey=None):
        """
        Get information about the Applications and Addons licensed to my account.
        @param tracekey: (optional) execution tracekey
        @return: The list of Applications and Addons configured for the account.
        """
        params = self._tracekey_dict(tracekey)
        return self._get_json_view(VIEWS_URLS["my_apps_and_addons"], params)

    def all_apps_addons_view(self, tracekey=None):
        """
        Get information about all possible Applications and Addons.
        @param tracekey: (optional) execution tracekey
        @return: The list of all possible Applications and Addons.
        """
        params = self._tracekey_dict(tracekey)
        return self._get_json_view(VIEWS_URLS["all_apps_and_addons"], params)

    def my_courses_view(self, tracekey=None):
        """Get basic information about courses of classes assigned to authenticated user.

        The information comes from the NAPI server. Please see the server
        documentation for up-to-date information about what is being sent.

        @param tracekey: (optional) execution tracekey
        @return: The list of courses found by the NAPI Server.
        """
        params = self._tracekey_dict(tracekey)
        url = VIEWS_URLS["my_courses"]
        return self._get_json_view(url, params)

    def courses_view(self, course_uids=None, course_enrollment_uids=None, school_year=None, tracekey=None):
        """Get basic information about courses in the account.

        The information comes from the NAPI server. Please see the server
        documentation for up-to-date information about what is being sent.

        @param course_uids: (optional) A list of Course UIDs
                         Default: None (this will return all courses in
                                  the authenticated user's account)
        @param tracekey: (optional) execution tracekey
        @return: The list of courses found by the NAPI Server.
        """
        params = {URL_PARAM_COURSE_UIDS: course_uids or [],
                  URL_PARAM_COURSE_ENROLLMENT_UIDS: course_enrollment_uids or []}

        flags = [
            (URL_PARAM_WITH_SCHOOL_YEAR, school_year or None)
        ]
        params.update(self._fill_values(flags))

        params.update(self._tracekey_dict(tracekey))
        url = VIEWS_URLS["courses"]
        return self._get_json_view(url, params)

    # Resources

    def account_subjects_update(self, account_uid, subject_area_uids=None, tracekey=None):
        """Update the subjects for the specified account.

        This operation will modify the account. Please see the NAPI server
        documentation for up-to-date information about what is being sent.

        @param account_uid: UID of account whose subjects you want to update.
        @param subject_area_uids: UIDs of subject areas that you want configured for account.
        @param tracekey: (optional) execution tracekey
        """
        params = {
            URL_PARAM_SUBJECT_AREA_UIDS: subject_area_uids or [],
        }

        params.update(self._tracekey_dict(tracekey))
        url = RESOURCE_URLS["account"].format(account_uid=account_uid)
        self._put_resource(url, params)

    def staff_update(self, staff_uid, first_name, last_name, email,
                     title="", grade="", phone="", fax="", tracekey=None):
        """Update the staff record.  Fields that are null will be updated
        to null.

        Please see the NAPI server
        documentation for up-to-date information about what is being sent.

        @param staff_uid: UID of staff you want to update.
        @param first_name: First name of the staff.
        @param last_name: Last name of the staff.
        @param email: Email address of the staff.
        @param title: (optional) String title of the staff.
        @param grade: (optional) String grade of the staff.
        @param phone: (optional) Phone number of the staff.
        @param fax: (optional) Fax number of the staff.
        @param tracekey: (optional) execution tracekey
        """

        # any None fields will be made to blank string
        params = {
            URL_PARAM_FIRST_NAME: [first_name],
            URL_PARAM_LAST_NAME: [last_name],
            URL_PARAM_EMAIL: [email],
            URL_PARAM_TITLE: [title],
            URL_PARAM_GRADE: [grade],
            URL_PARAM_PHONE: [phone],
            URL_PARAM_FAX: [fax],
        }

        params.update(self._tracekey_dict(tracekey))
        url = RESOURCE_URLS["staff"].format(staff_uid=staff_uid)
        self._put_resource(url, params)

    def sync_session_create(self, sync_session_status, tracekey=None):
        """Create a sync session record with given status.

        This operation will modify the sync database. Please see the NAPI
        server documentation for up-to-date information about what is being
        sent.

        @param sync_session_status: Sync result (success, partial, error, or abort)
        @param tracekey: (optional) execution tracekey
        """
        params = {
            URL_PARAM_SYNC_SESSION_STATUS: sync_session_status,
        }

        params.update(self._tracekey_dict(tracekey))
        url = RESOURCE_URLS["sync_session"]
        self._post_resource(url, params)

    def sync_session_show(self, tracekey=None):
        """Get the sync session record for the current user

        @param tracekey: (optional) execution tracekey
        """
        params = self._tracekey_dict(tracekey)
        url = RESOURCE_URLS["sync_session"]
        return self._get_resource(url, params)
