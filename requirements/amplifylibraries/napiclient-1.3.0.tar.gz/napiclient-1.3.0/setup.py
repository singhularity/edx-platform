#! /opt/wgen-3p/python26/bin/python

from setuptools import setup, find_packages

setup(name='napiclient',
      description='Python client used to access the mClass Enrollment API',
      author='Enrollment Team',
      author_email='enrollment_team@wgen.net',
      install_requires=["simplejson==2.5.2",
                        "wgen.httpconn>=13.1.0,<14.0.0"],
      package_dir={'': 'src'},
      # using '' to pull any python modules in the 'src' dir.
      #   its safe to ignore any warning from setuptools about this
      packages=find_packages('src', exclude=['*.tests', '*.tests.*', 'tests.*', 'tests']),
      version='1.3.0')
