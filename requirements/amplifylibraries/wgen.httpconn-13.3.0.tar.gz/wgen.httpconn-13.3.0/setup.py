#!/opt/wgen-3p/python26/bin/python

from setuptools import setup, find_packages


setup(
    name='wgen.httpconn',
    description='Common HTTP connection library',
    author='SPT',
    author_email='spt@wgen.net',
    packages=find_packages(exclude=['tests']),
    namespace_packages=['wgen'],
    version='13.3.0',
    zip_safe=False,
    setup_requires=['nose'],
    install_requires=['wgen.logger>=1.3.3,<3.0.0'],
    tests_require=['coverage', 'mock==0.7.2', 'nose', 'unittest2'])
