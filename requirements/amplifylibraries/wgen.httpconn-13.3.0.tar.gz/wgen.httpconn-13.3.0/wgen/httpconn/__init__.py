"""
HTTP Connection Factory which will produce connections that require passing
the MAS authentication token as a cookie for each request.
"""
import base64
import httplib
import socket
import urllib2
from urllib import urlencode

from wgen.logger import logging


#Constants
_ACTION_TYPE_GET = 'GET'
_ACTION_TYPE_POST = 'POST'

TRACEKEY_HEADER = 'X-WGEN-TraceKey'
WEB_SERVICE_VERSION_HEADER = 'X-WGEN-WebServiceVersion'

def encode_parameters(parameters):
    """
    Encodes a set of parameters.

    `parameters`
        Dictionary with key-value pairs to be encoded.

    Returns a `urlencoded` string representing the dictionary.  Duplicate keys
    appear multiple times (i.e., `a=1&a=2`).
    """
    param_pairs = (
        (key, ",".join([str(value) for value in value_list]))
        for key, value_list in parameters.items())

    # Encode our URL Parameters
    return urlencode(dict(param_pairs))


class UnsupportedHttpAction(Exception):
    """ Raised when an unknown HTTP action is specified. """
    pass


class HttpConnectionError(Exception):
    """
    Wrapper for an HTTP Connection that stores its status code, error message,
    and response body.
    """

    def __init__(self, error_msg, status_code=None, response_body=None):
        """
        ``error_message``
            a verbose message that can be logged or displayed to the user
        ``error_code``
            a brief error code that's useful for programs analyzing an error
        ``error_type``
            an error type that's useful for programs analyzing an error
        ``stack``
            an error stacktrace that can be used to analyze the error
        """
        super(HttpConnectionError, self).__init__(error_msg)
        self.status_code = status_code
        self.response_body = response_body
        self.error_msg = error_msg


class HttpConnectionFactory(object):
    """
    HTTP Connection Factory to dole out connections to the given host.
    """

    def __init__(self, host_url, host_port, username, passwd,
                 mas_auth_token_name='sso.auth_token',
                 timeout=socket._GLOBAL_DEFAULT_TIMEOUT):
        """
        ``host_url``
            URL used for generated connections.
        ``host_port``
            Port used for generating connections.
        ``username``
            MAS username to use
        ``password``
            MAS password to use
        ``mas_auth_token_name``
            If specified, will be used as the cookie name for the auth_token.
        ``timeout``
            Specify the amount of time, in seconds, before a request times out.
        """
        self._host_url = host_url
        self._host_port = host_port
        self._username = username
        self._passwd = passwd
        self._mas_auth_token_name = mas_auth_token_name
        self._timeout = timeout

    def get_connection(self, mas_auth_token_value, tracekey=None, web_service_version=None):
        """
        Creates a connection to the host with the given mas_auth_token_value.
        The token is stored within the connection so the user does not have to
        provide it for each request.

        ``mas_auth_token_value``
            A string representing the user's auth_token as returned by MAS.
        ``tracekey``
            a string that is a unique identifier for the scope of the request, to be
            used as a trace key throughout all logging and auditing of the requested service
            processing
        ``web_service_version``
            an integer indicating which version of the web service to be called
            for web services supporting multiple versions

        Returns a new :class:`HttpConnection` instance.
        """
        return HttpConnection(
            self._host_url, self._host_port, self._username, self._passwd,
            self._mas_auth_token_name, mas_auth_token_value, self._timeout,
            tracekey, web_service_version)


class HttpConnection(object):

    def __init__(self, host_url, host_port, username, passwd, mas_auth_token_name,
            mas_auth_token_value, timeout, tracekey=None, web_service_version=None):
        """
        Creates a connection to the host with the given
        ``mas_auth_token_value``.

        ``mas_auth_token_value``
            A string representing the user's auth_token as returned by MAS.
        ``timeout``
            The timeout length, in seconds
        ``tracekey``
            a string that is a unique identifier for the scope of the request, to be
            used as a trace key throughout all logging and auditing of the requested service
            processing
        ``web_service_version``
            an integer indicating which version of the web service to be called
            for web services supporting multiple versions
        """
        # build full url for use with urllib2
        self._host_url = "%s:%s" % (host_url.strip("/"), host_port)
        self._host_port = host_port
        self._timeout = timeout

        auth_token_cookie = "%s=%s" % (
                mas_auth_token_name, mas_auth_token_value)
        password_hash = base64.b64encode(":".join((username, passwd)))

        self._opener = urllib2.build_opener()
        extra_headers = [
            ('Authorization', "Basic %s" % password_hash),
            ('Cookie', auth_token_cookie)]
        self._opener.addheaders.extend(extra_headers)
        self._tracekey = tracekey
        self._web_service_version = web_service_version

    def set_web_service_version_number(self, web_service_version):
        self._web_service_version = web_service_version

    def _make_request(self, request, trace_key):
        url = request.get_full_url()
        method = request.get_method()

        # add the trace key header if value available
        if trace_key:
            active_tracekey = trace_key
        elif self._tracekey:
            active_tracekey = self._tracekey
        else:
            active_tracekey = None

        if active_tracekey:
            request.add_header(TRACEKEY_HEADER, active_tracekey)

        if self._web_service_version:  # value has been set, either in __init__ or by setting it
            request.add_header(WEB_SERVICE_VERSION_HEADER, self._web_service_version)

        try:
            # Execute the Request
            response = self._opener.open(request, timeout=self._timeout)
        except urllib2.HTTPError, exc:
            # Separating error handling between HTTPError and the rest of the
            # errors(URLErrors etc.). So HTTPError exception can have error
            # code and json error returend by server.
            errmsg = "Unable to [%s] at server [%s]. Exception: [%s]" % (
                method, url, exc)
            logging.exception(errmsg, "wgen.httpconn.HTTPConnection._make_request",
                              tracekey=active_tracekey)

            # exc.read() will give json object returned by server which
            # contains error detail
            if exc.code in (httplib.FORBIDDEN, httplib.UNAUTHORIZED):
                raise HttpConnectionError(
                    "The User was not authorized to perform this action. \n%s" % errmsg, exc.code)
            if not hasattr(exc, "read"):
                raise HttpConnectionError(errmsg, exc.code)
            else:
                raise HttpConnectionError(errmsg, exc.code, exc.read())
        except Exception, exc:
            errmsg = "Unable to [%s] at server [%s]. Exception: [%s]" % (
                method, url, exc)
            logging.exception(errmsg,
                              "wgen.httpconn.HTTPConnection._make_request",
                              tracekey=active_tracekey)
            raise

        return response

    def delete(self, url, params={}, trace_key=None):
        """
        Executes an HTTP DELETE request against the HOST at the given URL using
        the params.

        ``url``
            The path against which the GET request should be executed.
        ``params``
            A dict object containing all parameters that should be passed in
            the URL.
        ``trace_key``
            a string that is a unique identifier for the scope of the request, to be
            used as a trace key throughout all logging and auditing of the requested service
            processing

        Returns :class:`urllib2.Response` with the response from the server.
        """
        param_string = "?%s" % encode_parameters(params) if params else ""
        request_url = "".join((self._host_url, url, param_string))
        request = urllib2.Request(request_url)
        request.get_method = lambda: 'DELETE'
        return self._make_request(request, trace_key)

    def get(self, url, params={}, trace_key=None):
        """
        Executes an HTTP GET request against the HOST at the given URL using
        the params.

        ``url``
            The path against which the GET request should be executed.
        ``params``
            A dict object containing all parameters that should be passed in
            the URL.
        ``trace_key``
            a string that is a unique identifier for the scope of the request, to be
            used as a trace key throughout all logging and auditing of the requested service
            processing

        Returns :class:`urllib2.Response` with the response from the server.
        """
        param_string = "?%s" % encode_parameters(params) if params else ""
        request_url = "".join((self._host_url, url, param_string))
        request = urllib2.Request(request_url)
        return self._make_request(request, trace_key)

    def post(self, url, params={}, trace_key=None):
        """
        Executes an HTTP POST request against the HOST at the given URL using
        the params.

        ``url``
            The path against which the GET request should be executed.
        ``params``
            A dict object containing all parameters that should be passed in
            the URL.
        ``trace_key``
            a string that is a unique identifier for the scope of the request, to be
            used as a trace key throughout all logging and auditing of the requested service
            processing

        Returns :class:`urllib2.Response` with the response from the server.
        """
        param_string = encode_parameters(params) if params else None
        request_url = "".join((self._host_url, url))
        request = urllib2.Request(request_url, param_string)
        return self._make_request(request, trace_key)

    def put(self, url, params={}, trace_key=None):
        """
        Executes an HTTP DELETE request against the HOST at the given URL using
        the params.

        ``url``
            The path against which the GET request should be executed.
        ``params``
            A dict object containing all parameters that should be passed in
            the URL.
        ``trace_key``
            a string that is a unique identifier for the scope of the request, to be
            used as a trace key throughout all logging and auditing of the requested service
            processing

        Returns :class:`urllib2.Response` with the response from the server.
        """
        param_string = encode_parameters(params) if params else None
        request_url = "".join((self._host_url, url))

        request = urllib2.Request(request_url, param_string)
        request.get_method = lambda: "PUT"
        return self._make_request(request, trace_key)
